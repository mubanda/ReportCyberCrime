package com.example.reportcybercrime.entities;

public class Admin {
}
