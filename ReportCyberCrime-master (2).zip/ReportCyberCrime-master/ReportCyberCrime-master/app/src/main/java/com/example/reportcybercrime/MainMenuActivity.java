package com.example.reportcybercrime;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        Button but1;
            but1 = (Button) findViewById(R.id.but1);
            but1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent go = new Intent(MainMenuActivity.this, MainActivity.class);
                    startActivity(go);
                }

            });


        Button button2;
            button2 = (Button) findViewById(R.id.button5);
            button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(MainMenuActivity.this, SelectSectorsActivity.class);
                    startActivity(i);
                }
            });

        Button button6;
            button6 = (Button) findViewById(R.id.button6);
            button6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent j = new Intent(MainMenuActivity.this, ContactUsActivity.class);
                    startActivity(j);
                }
            });
        }
    }


