package com.example.reportcybercrime;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Layout;
import android.view.WindowManager;

public class SplashActivity extends AppCompatActivity implements Runnable {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        Handler splashHandler = new Handler();
        splashHandler.postDelayed(this, 4000);



    }
    @Override
    public void run(){
        Intent intent = new Intent( SplashActivity.this, MainActivity.class );
        startActivity( intent );
        finish();
        SplashActivity.this.startActivity( intent );



    }

}
